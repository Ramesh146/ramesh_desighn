package com.rahul.Design_Patterns.Behavioral_patterns.IteratorPattern;

public interface Container {
   public Iterator getIterator();
}