package com.rahul.Design_Patterns.Structural_patterns.ProxyPattern;

public interface Image {
   void display();
}