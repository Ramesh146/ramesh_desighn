package com.rahul.Design_Patterns.Creational_patterns.FactoryPattern;

public interface Shape {
   void draw();
}